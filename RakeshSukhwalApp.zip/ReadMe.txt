Compile and Target SDK Version: 28

Design pattern used: MVVM design pattern

Jetpack component used:
- Data Binding
- Live Data
- View Model
- ROOM database

NOTE: The URL coming in the response is not complete. So the image is not displayed on Item Details screen. I have added the code to display the image. If the image URL is correct, it will display the image.
