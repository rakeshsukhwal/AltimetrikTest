package com.app.altimetrik.kickstarter.view.adapters;

import android.content.res.Resources;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;

import com.app.altimetrik.kickstarter.R;
import com.app.altimetrik.kickstarter.databinding.ListItemRowBinding;
import com.app.altimetrik.kickstarter.model.Item;
import com.app.altimetrik.kickstarter.view.activities.MainActivity;

import java.util.ArrayList;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.RecyclerView;

/**
 * This is adapter class to display the item list. It is implementing Filterable interface to support the search functionality
 * */
public class ItemListAdapter extends RecyclerView.Adapter<ItemListAdapter.ViewHolder> implements Filterable {
    private List<Item> itemList;
    private List<Item> filteredList = new ArrayList<>();
    private MainActivity parentActivity;
    private ListFilter filter;

    public ItemListAdapter(MainActivity activity, List<Item> itemList) {
        this.itemList = itemList;
        this.parentActivity = activity;
        this.filteredList.addAll(itemList);
    }

    @Override
    public int getItemCount() {
        return filteredList.size();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        ListItemRowBinding binding = DataBindingUtil.inflate(LayoutInflater.from(viewGroup.getContext()),
                R.layout.list_item_row, viewGroup, false);

        return new ViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder viewHolder, int position) {
        Item item = filteredList.get(position);
        viewHolder.binding.title.setText(item.getTitle());
        viewHolder.binding.blurb.setText(item.getBlurb());
        Resources res = parentActivity.getResources();
        viewHolder.binding.pleage.setText(String.format(res.getString(R.string.pleage), Integer.toString(item.getAmtPledged())));
        viewHolder.binding.backers.setText(String.format(res.getString(R.string.backers), item.getNumBackers()));

        viewHolder.binding.itemView.setTag(filteredList.get(position));
        viewHolder.binding.itemView.setOnClickListener(mOnClickListener);
    }

    public void updateData(List<Item> updatedList){
        this.itemList = updatedList;
        this.filteredList.clear();
        this.filteredList.addAll(updatedList);
        notifyDataSetChanged();
    }

    @Override
    public Filter getFilter() {
        if (filter == null){
            filter = new ListFilter();
        }
        return filter;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder{
        ListItemRowBinding binding;

        public ViewHolder(ListItemRowBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }
    }

    private final View.OnClickListener mOnClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            Item item = (Item) view.getTag();
            parentActivity.onItemSelected(item);

        }
    };

    private class ListFilter extends Filter{

        @Override
        protected FilterResults performFiltering(CharSequence constraint) {
            String search = constraint.toString();
            FilterResults results = new FilterResults();
            if (search.isEmpty()){
                results.values = itemList;
                results.count = itemList.size();
            }else{
                List<Item> list = new ArrayList<>();
                for (Item item : itemList){
                    if (item.getTitle().toLowerCase().contains(search.toLowerCase())){
                        list.add(item);
                    }
                }
                results.values = list;
                results.count = list.size();
            }
            return results;
        }

        @Override
        protected void publishResults(CharSequence constraint, FilterResults results) {
            filteredList.clear();
            filteredList.addAll((List<Item>) results.values);
            notifyDataSetChanged();
        }
    }
}
