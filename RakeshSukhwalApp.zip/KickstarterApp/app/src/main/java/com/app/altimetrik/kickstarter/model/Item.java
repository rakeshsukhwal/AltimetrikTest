package com.app.altimetrik.kickstarter.model;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.SerializedName;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;


/**
 * This is entity class for item. It contains the item details. This entity class is also used for ROOM database.
 * */
@Entity
public class Item implements Parcelable {
    @PrimaryKey(autoGenerate = true)
    public int id;

    @SerializedName("s.no")
    @ColumnInfo(name = "s_no")
    private int sNo;

    @SerializedName("amt.pledged")
    @ColumnInfo(name = "amt_pledged")
    private int amtPledged;

    @SerializedName("blurb")
    @ColumnInfo(name = "blurb")
    private String blurb;

    @SerializedName("by")
    @ColumnInfo(name = "by_name")
    private String by;

    @SerializedName("country")
    @ColumnInfo(name = "country")
    private String country;

    @SerializedName("currency")
    @ColumnInfo(name = "currency")
    private String currency;

    @SerializedName("end.time")
    @ColumnInfo(name = "end_time")
    private String endTime;

    @SerializedName("location")
    @ColumnInfo(name = "location")
    private String location;

    @SerializedName("percentage.funded")
    @ColumnInfo(name = "percentage_funded")
    private int percentageFunded;

    @SerializedName("num.backers")
    @ColumnInfo(name = "num_backers")
    private String numBackers;

    @SerializedName("state")
    @ColumnInfo(name = "state")
    private String state;

    @SerializedName("title")
    @ColumnInfo(name = "title")
    private String title;

    @SerializedName("type")
    @ColumnInfo(name = "type_value")
    private String type;

    @SerializedName("url")
    @ColumnInfo(name = "url")
    private String url;

    public Item() {
    }

    public int getSNo() {
        return sNo;
    }

    public void setSNo(int sNo) {
        this.sNo = sNo;
    }

    public int getAmtPledged() {
        return amtPledged;
    }

    public void setAmtPledged(int amtPledged) {
        this.amtPledged = amtPledged;
    }

    public String getBlurb() {
        return blurb;
    }

    public void setBlurb(String blurb) {
        this.blurb = blurb;
    }

    public String getBy() {
        return by;
    }

    public void setBy(String by) {
        this.by = by;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public int getPercentageFunded() {
        return percentageFunded;
    }

    public void setPercentageFunded(int percentageFunded) {
        this.percentageFunded = percentageFunded;
    }

    public String getNumBackers() {
        return numBackers;
    }

    public void setNumBackers(String numBackers) {
        this.numBackers = numBackers;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(id);
        dest.writeInt(sNo);
        dest.writeInt(amtPledged);
        dest.writeString(blurb);
        dest.writeString(by);
        dest.writeString(country);
        dest.writeString(currency);
        dest.writeString(endTime);
        dest.writeString(location);
        dest.writeInt(percentageFunded);
        dest.writeString(numBackers);
        dest.writeString(state);
        dest.writeString(title);
        dest.writeString(type);
        dest.writeString(url);
    }

    protected Item(Parcel in) {
        id = in.readInt();
        sNo = in.readInt();
        amtPledged = in.readInt();
        blurb = in.readString();
        by = in.readString();
        country = in.readString();
        currency = in.readString();
        endTime = in.readString();
        location = in.readString();
        percentageFunded = in.readInt();
        numBackers = in.readString();
        state = in.readString();
        title = in.readString();
        type = in.readString();
        url = in.readString();
    }

    public static final Creator<Item> CREATOR = new Creator<Item>() {
        @Override
        public Item createFromParcel(Parcel in) {
            return new Item(in);
        }

        @Override
        public Item[] newArray(int size) {
            return new Item[size];
        }
    };
}
