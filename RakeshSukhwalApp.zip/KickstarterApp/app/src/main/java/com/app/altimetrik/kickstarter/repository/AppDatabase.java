package com.app.altimetrik.kickstarter.repository;

import com.app.altimetrik.kickstarter.model.Item;
import com.app.altimetrik.kickstarter.repository.dao.ItemDao;

import androidx.room.Database;
import androidx.room.RoomDatabase;

/**
 * ROOM Database
 * */
@Database(entities = {Item.class}, version = 1)
public abstract class AppDatabase extends RoomDatabase {
    public abstract ItemDao itemDao();
}