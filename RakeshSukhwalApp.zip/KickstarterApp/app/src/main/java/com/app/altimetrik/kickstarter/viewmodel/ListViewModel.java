package com.app.altimetrik.kickstarter.viewmodel;

import android.app.Application;
import android.util.Log;

import com.app.altimetrik.kickstarter.model.Item;
import com.app.altimetrik.kickstarter.repository.LocalRepository;
import com.app.altimetrik.kickstarter.repository.NetworkRepository;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.MutableLiveData;

/**
 * This is view model class for Main Activity. It contains data list.
 * It will load the data list from Network Repository and Local Repository
 * */
public class ListViewModel extends AndroidViewModel {
    private static final String TAG = "ListViewModel";
    private NetworkRepository networkRepository;
    private LocalRepository localRepository;
    private Executor executor = Executors.newFixedThreadPool(2);

    /**
     * This is mutable live data containing list.
     * */
    private MutableLiveData<ArrayList<Item>> liveDataList;

    public ListViewModel(@NonNull Application application) {
        super(application);
        liveDataList = new MutableLiveData<>();
        networkRepository = new NetworkRepository(getApplication().getApplicationContext());
        localRepository = new LocalRepository(getApplication().getApplicationContext());
    }

    /**
     * This method return mutable live data object containing list
     * @return It returns MutableLiveData<List<Item>>
     * */
    public MutableLiveData<ArrayList<Item>> getLiveDataList() {
        return liveDataList;
    }

    /**
     * Loads data list from network repository(Server API) and update the response in live data
     * */
    public void loadDataFromServer(){
        networkRepository.loadListFromServer(liveDataList);
    }

    /**
     * Load next 20 record from locally cached data in ROOM database
     * */
    public void loadNext20(final int currentSNum){
        executor.execute(new Runnable() {
            @Override
            public void run() {
                int start = currentSNum + 1;
                Log.d(TAG, "Loading next 20 items, starting from :"+start);
                List<Item> nextList = localRepository.getBetweenSerialNo(start, start+20);
                ArrayList<Item> oldData = liveDataList.getValue();
                if (oldData == null){
                    oldData = new ArrayList<>();
                }
                if (nextList != null) {
                    oldData.addAll(nextList);
                }
                liveDataList.postValue(oldData);
            }
        });
    }
}
