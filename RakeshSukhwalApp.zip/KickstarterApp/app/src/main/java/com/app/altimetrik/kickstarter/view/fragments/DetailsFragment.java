package com.app.altimetrik.kickstarter.view.fragments;

import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.app.altimetrik.kickstarter.R;
import com.app.altimetrik.kickstarter.databinding.DetailsFragmentBinding;
import com.app.altimetrik.kickstarter.model.Item;
import com.app.altimetrik.kickstarter.viewmodel.SharedDetailsViewModel;
import com.facebook.drawee.backends.pipeline.Fresco;
import com.facebook.drawee.interfaces.DraweeController;
import com.facebook.imagepipeline.request.ImageRequest;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.databinding.DataBindingUtil;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProviders;

public class DetailsFragment extends Fragment {

    private DetailsFragmentBinding binding;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        binding = DataBindingUtil.inflate(inflater, R.layout.details_fragment, container, false);
        binding.setFragment(this);
        return binding.getRoot();
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

    }

    @Override
    public void onResume() {
        super.onResume();
        displayData();
    }

    private void displayData(){
        SharedDetailsViewModel sharedViewModel = ViewModelProviders.of(getActivity()).get(SharedDetailsViewModel.class);
        Item selectedItem = sharedViewModel.getSelectedItem();
        if (selectedItem != null){
            binding.title.setText(selectedItem.getTitle());
            binding.blurb.setText(selectedItem.getBlurb());

            binding.pleage.setText(String.format(getString(R.string.amount_pleage), Integer.toString(selectedItem.getAmtPledged())));
            binding.backers.setText(String.format(getString(R.string.number_backers), selectedItem.getNumBackers()));
            binding.by.setText(String.format(getString(R.string.by), selectedItem.getBy()));
            binding.location.setText(String.format(getString(R.string.location), selectedItem.getLocation()));
            binding.country.setText(String.format(getString(R.string.country), selectedItem.getCountry()));

            binding.currency.setText(String.format(getString(R.string.currency), selectedItem.getCurrency()));
            binding.endTime.setText(String.format(getString(R.string.end_time), selectedItem.getEndTime()));
            binding.percentageFunded.setText(String.format(getString(R.string.percentage_funded), Integer.toString(selectedItem.getPercentageFunded())));
            binding.state.setText(String.format(getString(R.string.state), selectedItem.getState()));
            binding.type.setText(String.format(getString(R.string.type), selectedItem.getType()));

            String imageUrl = null;
            if (selectedItem.getUrl() != null && selectedItem.getUrl().startsWith("http")){//Valid image URL
                imageUrl = selectedItem.getUrl();
            }

            if (imageUrl != null) {//Image URL is available, display image
                binding.newsImage.setVisibility(View.VISIBLE);
                DraweeController draweeController = Fresco.newDraweeControllerBuilder()
                        .setImageRequest(ImageRequest.fromUri(Uri.parse(imageUrl)))
                        .setOldController(binding.newsImage.getController()).build();
                binding.newsImage.setController(draweeController);
            }else{//Image URL is not available, hide image view
                binding.newsImage.setVisibility(View.GONE);
            }
        }
    }
}
