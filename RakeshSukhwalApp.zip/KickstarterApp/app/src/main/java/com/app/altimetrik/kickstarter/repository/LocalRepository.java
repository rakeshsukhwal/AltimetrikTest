package com.app.altimetrik.kickstarter.repository;

import android.content.Context;

import com.app.altimetrik.kickstarter.model.Item;

import java.util.List;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

import androidx.lifecycle.LiveData;
import androidx.room.Room;

/**
 * Repository class to save/read the data from locally cached data in ROOM database
 * */
public class LocalRepository {
    private String DB_NAME = "items_db";
    private AppDatabase database;
    private final Executor executor = Executors.newFixedThreadPool(2);

    public LocalRepository(Context context) {
        database = Room.databaseBuilder(context, AppDatabase.class, DB_NAME).build();
    }

    public void insertItem(final Item... items){
        database.itemDao().insertAll(items);
    }

    public void updateItem(final Item item){
        database.itemDao().update(item);
    }

    public void deleteAll(){
        database.itemDao().deleteAll();
    }

    public LiveData<List<Item>> getAll(){
        return database.itemDao().getAll();
    }

    public List<Item> getBetweenSerialNo(int start, int end){
        return database.itemDao().getBetweenSerialNo(start, end);
    }
}
