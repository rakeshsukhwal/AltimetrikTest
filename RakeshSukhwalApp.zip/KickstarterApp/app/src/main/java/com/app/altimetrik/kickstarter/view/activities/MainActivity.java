package com.app.altimetrik.kickstarter.view.activities;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import com.app.altimetrik.kickstarter.R;
import com.app.altimetrik.kickstarter.databinding.ActivityMainBinding;
import com.app.altimetrik.kickstarter.model.Item;
import com.app.altimetrik.kickstarter.view.adapters.ItemListAdapter;
import com.app.altimetrik.kickstarter.view.fragments.DetailsFragment;
import com.app.altimetrik.kickstarter.viewmodel.ListViewModel;
import com.app.altimetrik.kickstarter.viewmodel.SharedDetailsViewModel;
import com.facebook.drawee.backends.pipeline.Fresco;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

/**
 * This activity class displays the list of data.
 * If the device is tablet, it will have two pane layout, one will display data list and one will display details of selected item.
 * */
public class MainActivity extends AppCompatActivity{
    private static final String TAG = "ListViewModel";
    private List<Item> itemList = new ArrayList<>();
    private ActivityMainBinding binding;
    private ListViewModel viewModel;
    private SharedDetailsViewModel sharedViewModel;
    private boolean isTwoPane;
    private ItemListAdapter adapter;
    private boolean isLoading;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = DataBindingUtil.setContentView(this, R.layout.activity_main);

        Fresco.initialize(this);

        sharedViewModel = ViewModelProviders.of(this).get(SharedDetailsViewModel.class);
        viewModel = ViewModelProviders.of(this).get(ListViewModel.class);

        if (findViewById(R.id.detail_container) != null) {
            // The detail container view will be present only in the large-screen layouts (res/values-w900dp).
            // If this view is present, then the activity should be in two-pane mode.
            isTwoPane = true;
        }

        adapter = new ItemListAdapter(this, itemList);
        binding.list.setAdapter(adapter);
        loadData();
        addSearch();
        addScrollListener();
    }

    private void addSearch(){
        binding.etSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence search, int start, int count, int after) { }

            @Override
            public void onTextChanged(CharSequence search, int start, int before, int count) {
                adapter.getFilter().filter(search);
            }

            @Override
            public void afterTextChanged(Editable s) { }
        });
    }

    private void addScrollListener(){
        binding.list.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(@NonNull RecyclerView recyclerView, int newState) {
                super.onScrollStateChanged(recyclerView, newState);
            }

            @Override
            public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                if (!isLoading) {
                    if (((LinearLayoutManager) Objects.requireNonNull(binding.list.getLayoutManager())).findLastCompletelyVisibleItemPosition() == itemList.size() - 1) {
                        //bottom of list, so load more data
                        loadMore();
                        isLoading = true;
                    }
                }
            }
        });

    }

    /**
     * This method call view model method to load next 20 record from locally cached data in ROOM database
     * */
    private void loadMore() {
        Log.d(TAG, "loadMore");
        if (itemList != null && itemList.size() > 0) {
            viewModel.loadNext20(itemList.get(itemList.size() - 1).getSNo());
        }else{
            viewModel.loadNext20(0);
        }
    }

    /**
     * This method load the data list from server by call view model method
     * */
    private void loadData(){
        //Display progress bar before starting call to load news data
        binding.progressBar.setVisibility(View.VISIBLE);

        //Set the observer for list live data. So once response is received, update the UI
        viewModel.getLiveDataList().observe(this, new Observer<List<Item>>() {
            @Override
            public void onChanged(List<Item> list) {
                isLoading = false;
                binding.progressBar.setVisibility(View.GONE);
                updateList(list);
            }
        });

        //Load data list from web API
        viewModel.loadDataFromServer();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_refresh) {
            loadData();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public void onItemSelected(Item selectedItem){
        sharedViewModel.setSelectedItem(selectedItem);
        if (isTwoPane){
            DetailsFragment fragment = new DetailsFragment();
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.detail_container, fragment)
                    .commit();
        }else {
            Intent intent = new Intent(MainActivity.this, DetailViewActivity.class);
            intent.putExtra(DetailViewActivity.EXTRA_ITEM, selectedItem);
            startActivity(intent);
        }
    }

    private void updateList(List<Item> list){
        this.itemList = list;
        if (itemList == null || itemList.isEmpty()){//Not able to get data, display error message
            binding.errorMsg.setVisibility(View.VISIBLE);
        }else{//Received data, display the list
            binding.errorMsg.setVisibility(View.GONE);
            adapter.updateData(list);
        }
    }
}
