package com.app.altimetrik.kickstarter.repository;

import android.content.Context;
import android.util.Log;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.app.altimetrik.kickstarter.model.Item;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

import androidx.annotation.NonNull;
import androidx.lifecycle.MutableLiveData;

/**
 * This is repository class to get list from server API
 * */
public class NetworkRepository {
    private static final String TAG = NetworkRepository.class.getSimpleName();
    private static final String URL ="http://starlord.hackerearth.com/kickstarter";

    private Context context;
    private LocalRepository localRepository;

    public NetworkRepository(@NonNull Context context) {
        this.context = context;
        this.localRepository = new LocalRepository(context);
    }

    public void loadListFromServer(final MutableLiveData<ArrayList<Item>> mutableLiveData){

        RequestQueue queue = Volley.newRequestQueue(context);
        StringRequest stringRequest = new StringRequest(Request.Method.GET, URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Log.d(TAG, "onResponse: response received");
                        String data = fixEncoding(response);
                        Gson gson = new Gson();
                        final ArrayList<Item> itemList = gson.fromJson(data, new TypeToken<List<Item>>(){}.getType());

                        if (itemList != null) {//Cached the data(in ROOM database) for future use
                            Executor executor = Executors.newFixedThreadPool(2);
                            executor.execute(new Runnable() {
                                @Override
                                public void run() {
                                    localRepository.deleteAll();//Clear old cached data
                                    for (Item item : itemList){
                                        localRepository.insertItem(item);
                                    }
                                    ArrayList<Item> firstList = (ArrayList<Item>)localRepository.getBetweenSerialNo(0, 19);
                                    mutableLiveData.postValue(firstList);
                                }
                            });
                        }
                    }
                },

                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        error.printStackTrace();
                        Log.e(TAG, "onErrorResponse: error=>"+error.getMessage());
                        ArrayList<Item> itemList = new ArrayList<>();
                        mutableLiveData.postValue(itemList);
                    }
                });

        queue.add(stringRequest);
    }

    /**
     * This method convert string response to UTF8 format
     * @param response: string response for parsing
     * @return String : String UTF8 formatted
     * */
    private  static String fixEncoding(String response) {
        try {
            byte[] u = response.getBytes(
                    StandardCharsets.ISO_8859_1);
            response = new String(u, StandardCharsets.UTF_8);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
        return response;
    }
}
