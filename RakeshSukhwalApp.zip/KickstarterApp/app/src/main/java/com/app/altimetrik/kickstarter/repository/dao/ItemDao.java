package com.app.altimetrik.kickstarter.repository.dao;

import com.app.altimetrik.kickstarter.model.Item;

import java.util.List;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

/**
 * Item DAO class for ROOM database
 * */
@Dao
public interface ItemDao {
    @Query("SELECT * FROM item")
    LiveData<List<Item>> getAll();

    @Query("SELECT * FROM item WHERE s_no >= :startNum and s_no <= :endNum ")
    List<Item> getBetweenSerialNo(int startNum, int endNum);

    @Query("SELECT * FROM item WHERE s_no = :sNum LIMIT 1")
    Item findBySerialNo(int sNum);

    @Insert
    void insertAll(Item... items);

    @Update
    void update(Item item);

    @Delete
    void delete(Item item);

    @Query("DELETE FROM item")
    void deleteAll();

}
